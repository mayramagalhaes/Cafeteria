
package PacotePersistencia;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class FileSerializable {

	private ObjectInputStream file;	
	private ObjectOutputStream fileOutput;
	private String name;
	private Object object[] = new Object[2];
	
	public FileSerializable(String name) {
		this.name = name;
	}
	public void openFileInput(){
		try{
			file = new ObjectInputStream(new FileInputStream(name + ".ser"));
		}catch(IOException ioException){
			System.err.println("OCORREU UM ERRO AO ABRIR O ARQUIVO: " + ioException);
		}
	}
	
	public void openFileOutput(){
		try{
			fileOutput = new ObjectOutputStream(new FileOutputStream(name + ".ser")); 
		}catch(IOException ioException){
			System.err.println("OCORREU UM ERRO AO ABRIR O ARQUIVO: %s " + ioException.getMessage());
		}		
	}
	public void closeFile(){
		try{
			file.close();
			fileOutput.close();
		}catch(IOException ioException){
			System.err.println("OCORREU UM ERRO AO FECHAR O ARQUIVO: " + ioException);
		}
	}
	public Object readFile(){
		Object objeto2 = new Object();
		
		try{	
			objeto2 = file.readObject();
		}catch(IOException ioException){
			System.err.println("OCORREU UM ERRO AO LER O ARQUIVO: " + ioException);
		}catch(ClassNotFoundException classNotFoundException){
			System.err.println("OCORREU UM ERRO AO LER O ARQUIVO: " + classNotFoundException);
		}	
		return objeto2;
	}
	
	public void writeFile(Object objeto){
		try{
			fileOutput.writeObject(objeto);			
		}catch(IOException ioException){
			System.err.printf("OCORREU UM ERRO AO ESCREVER NO ARQUIVO: %s\n ",ioException.getMessage());
			ioException.printStackTrace();
		}		
	}
	public void readFileAll(){
		for(int cont = 0; cont <= 1; cont++){	
			this.object[cont] = readFile();
		}	
	}
	public void print(){
		for(Object objeto3 : this.object){
			System.out.printf("\n%s",objeto3);
		}
	}
}
