/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ClassesPersistentes;

/**
 *
 * @author Junior
 */
public abstract class Usuario {
    public static enum  TipoUsuario{FUNCIONARIO,ADMINISTRADOR}
    
    private TipoUsuario usuario;
    private String Nome;
    
}
