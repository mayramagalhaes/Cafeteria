/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ClassesModelo;


import java.awt.event.ContainerEvent;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;

/**
 *
 * @author Junior
 */
public abstract class MyJFrame extends JFrame{
    protected JPopupMenu jPopupMenu1;
    // End of variables declaration
    
    public void changePanel(JPanel newPanel){
        this.getContentPane().removeAll();
        this.getContentPane().add(newPanel);
        this.revalidate();
        this.repaint();
    }
        
    public abstract void setEnabledOption(boolean enabled);
}
